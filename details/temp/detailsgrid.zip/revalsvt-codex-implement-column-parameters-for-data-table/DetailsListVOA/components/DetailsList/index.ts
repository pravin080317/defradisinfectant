export { Grid as DetailsList } from '../../Grid';
export type { GridProps } from '../../Grid';

